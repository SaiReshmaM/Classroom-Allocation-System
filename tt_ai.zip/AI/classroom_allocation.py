#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
Classroom Allocation System using Constraint Satisfaction Problem (CSP) techniques
Implements a solver for allocating classrooms to sections based on various constraints
"""

import random
import time
from collections import defaultdict

class ClassroomAllocation:
    """
    A CSP solver for classroom allocation problems
    
    Constraints:
    1. Each subject must have 3 hours per week
    2. Lab sessions must be continuous 2-hour blocks
    3. Theory classes can be split into 1.5-hour blocks for better scheduling when needed
    4. Ensure at least one hour between 12:00-14:00 is free for lunch
    5. No classroom should be allocated to more than one section within the same time slot
    """
    
    def __init__(self, classrooms, sections, days, time_slots):
        """Initialize the CSP solver with problem parameters"""
        self.classrooms = classrooms
        self.sections = sections
        self.days = days
        self.time_slots = time_slots
        
        # Identify lunch time slots (between 12:00-14:00)
        self.lunch_slots = [slot for slot in time_slots if "12:" in slot or "13:" in slot]
        
        # Dictionary to store subject requirements for each section
        # Format: {(section, subject): (hours_per_week, has_lab)}
        self.subject_requirements = {}
        
        # Dictionary to store the solution
        # Format: {(day, time_slot, classroom): (section, subject, is_lab)}
        self.solution = {}
        
        # Track section timetables for easy access
        # Format: {section: {day: {time_slot: (classroom, subject, is_lab)}}}
        self.section_timetables = {section: {day: {} for day in days} for section in sections}
        
        # Track classroom schedules for easy access
        # Format: {classroom: {day: {time_slot: (section, subject, is_lab)}}}
        self.classroom_schedules = {classroom: {day: {} for day in days} for classroom in classrooms}
        
        # Track allocation counts for uniform utilization
        # Format: {classroom: count}
        self.classroom_allocation_count = {classroom: 0 for classroom in classrooms}
        
        # Track subject allocations to ensure all requirements are met
        # Format: {(section, subject): [(day, time_slot, classroom, is_lab)]}
        self.subject_allocations = defaultdict(list)
        
        # Track lunch breaks for each section
        # Format: {section: {day: has_lunch_break}}
        self.lunch_breaks = {section: {day: False for day in days} for section in sections}

    def add_subject(self, section, subject, has_lab=False):
        """Add a subject with its requirements for a section"""
        if section not in self.sections:
            raise ValueError(f"Section {section} not in the list of sections")
        
        # All subjects have 3 hours per week (fixed requirement)
        hours_per_week = 3
        
        self.subject_requirements[(section, subject)] = (hours_per_week, has_lab)
    
    def is_consecutive_slot(self, day, time_slot1, time_slot2):
        """Check if two time slots are consecutive on the same day"""
        if day != day:
            return False
            
        # Get indices of the time slots
        try:
            idx1 = self.time_slots.index(time_slot1)
            idx2 = self.time_slots.index(time_slot2)
            return abs(idx1 - idx2) == 1
        except ValueError:
            return False
    
    def get_consecutive_slot(self, day, time_slot):
        """Get the next consecutive time slot on the same day"""
        try:
            idx = self.time_slots.index(time_slot)
            if idx + 1 < len(self.time_slots):
                return self.time_slots[idx + 1]
        except ValueError:
            pass
        return None
    
    def is_lunch_time(self, time_slot):
        """Check if a time slot is during lunch hours (12:00-14:00)"""
        return time_slot in self.lunch_slots
    
    def has_lunch_break(self, section, day):
        """Check if a section has a lunch break on a given day"""
        # Check if any lunch slot is free
        for slot in self.lunch_slots:
            if slot not in self.section_timetables[section][day]:
                return True
        return False
    
    def set_section_lunch_preference(self, section, preferred_lunch_slot):
        """
        Set a preferred lunch slot for a section
        
        Args:
            section: The section name
            preferred_lunch_slot: The preferred lunch slot (e.g., "12:00-12:55")
        """
        if not hasattr(self, 'section_lunch_preferences'):
            self.section_lunch_preferences = {}
        
        self.section_lunch_preferences[section] = preferred_lunch_slot
    
    def solve(self, time_limit=60):
        """
        Solve the classroom allocation problem using backtracking with constraint propagation
        
        Args:
            time_limit: Maximum time in seconds to spend on solving
            
        Returns:
            bool: True if a complete solution was found, False otherwise
        """
        start_time = time.time()
        
        # Clear any previous solution
        self.solution = {}
        self.section_timetables = {section: {day: {} for day in self.days} for section in self.sections}
        self.classroom_schedules = {classroom: {day: {} for day in self.days} for classroom in self.classrooms}
        self.classroom_allocation_count = {classroom: 0 for classroom in self.classrooms}
        self.subject_allocations = defaultdict(list)
        self.lunch_breaks = {section: {day: False for day in self.days} for section in self.sections}
        
        # Sort subjects by section number (to ensure consistent allocation)
        sorted_subjects = sorted(self.subject_requirements.items(), 
                                key=lambda x: (x[0][0], x[0][1]))  # Sort by section, then subject
        
        # Prioritize days to ensure even distribution across all weekdays
        # Saturday is excluded from allocation (kept as reserve)
        prioritized_days = [day for day in self.days if day != "Saturday"]
        
        # Use a balanced day order to ensure even distribution
        day_order = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday"]
        prioritized_days = [day for day in day_order if day in prioritized_days]
        
        print(f"Allocation order of days: {prioritized_days}")
        
        # Track day allocation counts to ensure even distribution
        day_allocation_counts = {day: 0 for day in prioritized_days}
        
        # Track lab allocations to ensure only one lab session per subject
        lab_allocations = {}
        
        # First, allocate lab sessions (they need consecutive 2-hour blocks)
        # Each lab subject gets exactly ONE 2-hour block per week
        for (section, subject), (hours, has_lab) in sorted_subjects:
            if has_lab:
                # Find a suitable 2-hour block for the lab
                lab_assigned = False
                
                # Sort days by current allocation count (least allocated first)
                sorted_days = sorted(prioritized_days, key=lambda d: day_allocation_counts[d])
                
                # Try to distribute labs evenly across days
                for day in sorted_days:
                    if lab_assigned:
                        break
                    
                    # Skip Saturday (reserve day)
                    if day == "Saturday":
                        continue
                        
                    for i in range(len(self.time_slots) - 1):  # Need 2 consecutive slots
                        time_slot1 = self.time_slots[i]
                        
                        # Skip if this is the combined 16:00-17:30 slot
                        if "16:00-17:30" in time_slot1:
                            continue
                            
                        # Get next slot
                        if i + 1 >= len(self.time_slots):
                            continue
                        time_slot2 = self.time_slots[i+1]
                        
                        # Skip lunch slots for labs
                        if self.is_lunch_time(time_slot1) or self.is_lunch_time(time_slot2):
                            continue
                        
                        # Check if both slots are available for this section
                        if (time_slot1 in self.section_timetables[section][day] or 
                            time_slot2 in self.section_timetables[section][day]):
                            continue
                        
                        # Find an available classroom for both slots
                        for classroom in self.classrooms:
                            if ((day, time_slot1, classroom) in self.solution or 
                                (day, time_slot2, classroom) in self.solution):
                                continue
                            
                            # Store this lab allocation to ensure we don't allocate more than one lab per subject
                            lab_subject_key = (section, subject)
                            if lab_subject_key in lab_allocations:
                                continue  # Skip if this lab subject already has an allocation
                            
                            # Allocate 2-hour lab block
                            self.solution[(day, time_slot1, classroom)] = (section, subject, True)
                            self.solution[(day, time_slot2, classroom)] = (section, subject, True)
                            
                            self.section_timetables[section][day][time_slot1] = (classroom, subject, True)
                            self.section_timetables[section][day][time_slot2] = (classroom, subject, True)
                            
                            self.classroom_schedules[classroom][day][time_slot1] = (section, subject, True)
                            self.classroom_schedules[classroom][day][time_slot2] = (section, subject, True)
                            
                            self.classroom_allocation_count[classroom] += 2
                            self.subject_allocations[(section, subject)].append((day, time_slot1, classroom, True))
                            self.subject_allocations[(section, subject)].append((day, time_slot2, classroom, True))
                            
                            # Record this lab allocation
                            lab_allocations[lab_subject_key] = (day, time_slot1, time_slot2, classroom)
                            
                            day_allocation_counts[day] += 2  # Update day allocation count
                            lab_assigned = True
                            break
        
        # Now allocate theory classes (3 hours per week)
        # Process subjects in a deterministic order to ensure consistent results
        for (section, subject), (hours, has_lab) in sorted_subjects:
            # For ALL subjects, we need 3 hours of theory regardless of lab status
            theory_hours = 3
            
            # Try to allocate theory hours
            hours_allocated = 0
            
            # Track allocations per day for this subject to ensure even distribution
            subject_day_allocations = {day: 0 for day in prioritized_days}
            
            # First, try to allocate in 2-hour continuous blocks where possible
            # This is more efficient than allocating individual hours
            while hours_allocated < theory_hours and theory_hours - hours_allocated >= 2:
                block_assigned = False
                
                # Sort days by current allocation count (least allocated first)
                sorted_days = sorted(prioritized_days, 
                                    key=lambda d: (subject_day_allocations[d], day_allocation_counts[d]))
                
                # Try each day in order of least allocations
                for day in sorted_days:
                    if block_assigned or hours_allocated >= theory_hours:
                        break
                    
                    # Try to find 2 consecutive slots
                    for i in range(len(self.time_slots) - 1):
                        if block_assigned or hours_allocated >= theory_hours:
                            break
                            
                        time_slot1 = self.time_slots[i]
                        time_slot2 = self.time_slots[i+1]
                        
                        # Skip lunch slots and combined slots
                        if (self.is_lunch_time(time_slot1) or self.is_lunch_time(time_slot2) or
                            "16:00-17:30" in time_slot1 or "16:00-17:30" in time_slot2):
                            continue
                        
                        # Skip if either slot is already allocated for this section
                        if (time_slot1 in self.section_timetables[section][day] or 
                            time_slot2 in self.section_timetables[section][day]):
                            continue
                        
                        # Try each classroom in order
                        for classroom in self.classrooms:
                            if ((day, time_slot1, classroom) in self.solution or 
                                (day, time_slot2, classroom) in self.solution):
                                continue
                            
                            # Allocate a 2-hour continuous block
                            self.solution[(day, time_slot1, classroom)] = (section, subject, False)
                            self.solution[(day, time_slot2, classroom)] = (section, subject, False)
                            
                            self.section_timetables[section][day][time_slot1] = (classroom, subject, False)
                            self.section_timetables[section][day][time_slot2] = (classroom, subject, False)
                            
                            self.classroom_schedules[classroom][day][time_slot1] = (section, subject, False)
                            self.classroom_schedules[classroom][day][time_slot2] = (section, subject, False)
                            
                            self.classroom_allocation_count[classroom] += 2
                            self.subject_allocations[(section, subject)].append((day, time_slot1, classroom, False))
                            self.subject_allocations[(section, subject)].append((day, time_slot2, classroom, False))
                            
                            hours_allocated += 2
                            subject_day_allocations[day] += 2
                            day_allocation_counts[day] += 2
                            block_assigned = True
                            break
                
                # If we couldn't assign a 2-hour block, break out and try individual hours
                if not block_assigned:
                    break
            
            # Then, allocate remaining hours in 1-hour blocks
            while hours_allocated < theory_hours:
                hour_assigned = False
                
                # Sort days by current allocation count (least allocated first)
                sorted_days = sorted(prioritized_days, 
                                    key=lambda d: (subject_day_allocations[d], day_allocation_counts[d]))
                
                # Try each day in order of least allocations
                for day in sorted_days:
                    if hour_assigned or hours_allocated >= theory_hours:
                        break
                    
                    # Try each time slot in order
                    for time_slot in self.time_slots:
                        if hour_assigned or hours_allocated >= theory_hours:
                            break
                            
                        # Skip the combined 16:00-17:30 slot in this pass
                        if "16:00-17:30" in time_slot:
                            continue
                            
                        # Handle lunch slots based on section preferences
                        if self.is_lunch_time(time_slot):
                            # If this section has a lunch preference
                            if hasattr(self, 'section_lunch_preferences') and section in self.section_lunch_preferences:
                                # Skip if this is the preferred lunch slot for this section
                                if time_slot == self.section_lunch_preferences[section]:
                                    continue
                        
                        # Skip if this slot is already allocated for this section
                        if time_slot in self.section_timetables[section][day]:
                            continue
                        
                        # Try each classroom in order
                        for classroom in self.classrooms:
                            if (day, time_slot, classroom) in self.solution:
                                continue
                            
                            # Allocate a single hour
                            self.solution[(day, time_slot, classroom)] = (section, subject, False)
                            self.section_timetables[section][day][time_slot] = (classroom, subject, False)
                            self.classroom_schedules[classroom][day][time_slot] = (section, subject, False)
                            self.classroom_allocation_count[classroom] += 1
                            self.subject_allocations[(section, subject)].append((day, time_slot, classroom, False))
                            
                            hours_allocated += 1
                            subject_day_allocations[day] += 1
                            day_allocation_counts[day] += 1
                            hour_assigned = True
                            break
                
                # If we couldn't assign a 1-hour block, break out and try the combined slot
                if not hour_assigned:
                    break
            
            # If we still need more hours, try the combined 16:00-17:30 slot
            remaining_hours = theory_hours - hours_allocated
            if remaining_hours > 0:
                # Sort days by current allocation count (least allocated first)
                sorted_days = sorted(prioritized_days, 
                                    key=lambda d: (subject_day_allocations[d], day_allocation_counts[d]))
                
                for day in sorted_days:
                    if remaining_hours <= 0:
                        break
                    
                    # Find the combined 16:00-17:30 slot
                    combined_slot = None
                    for slot in self.time_slots:
                        if "16:00-17:30" in slot:
                            combined_slot = slot
                            break
                    
                    if not combined_slot:
                        continue
                    
                    # Skip if this slot is already allocated for this section
                    if combined_slot in self.section_timetables[section][day]:
                        continue
                    
                    # Find an available classroom for the combined slot
                    for classroom in self.classrooms:
                        if (day, combined_slot, classroom) in self.solution:
                            continue
                        
                        # Allocate the combined 1.5-hour block
                        self.solution[(day, combined_slot, classroom)] = (section, subject, False)
                        self.section_timetables[section][day][combined_slot] = (classroom, subject, False)
                        self.classroom_schedules[classroom][day][combined_slot] = (section, subject, False)
                        self.classroom_allocation_count[classroom] += 1
                        self.subject_allocations[(section, subject)].append((day, combined_slot, classroom, False))
                        
                        # Count as 1.5 hours
                        remaining_hours -= 1.5
                        hours_allocated += 1.5
                        subject_day_allocations[day] += 1
                        day_allocation_counts[day] += 1  # Update global day allocation count
                        break
            
            # If we still need more hours, try using lunch slots as a last resort
            remaining_hours = theory_hours - hours_allocated
            if remaining_hours > 0:
                # Sort days by current allocation count (least allocated first)
                sorted_days = sorted(prioritized_days, 
                                    key=lambda d: (subject_day_allocations[d], day_allocation_counts[d]))
                
                for day in sorted_days:
                    if remaining_hours <= 0:
                        break
                    
                    # Try lunch slots that are NOT the preferred lunch slot for this section
                    for time_slot in self.lunch_slots:
                        if remaining_hours <= 0:
                            break
                            
                        # Skip if this is the preferred lunch slot for this section
                        if hasattr(self, 'section_lunch_preferences') and section in self.section_lunch_preferences:
                            if time_slot == self.section_lunch_preferences[section]:
                                continue
                        
                        # Skip if this slot is already allocated for this section
                        if time_slot in self.section_timetables[section][day]:
                            continue
                        
                        for classroom in self.classrooms:
                            if (day, time_slot, classroom) in self.solution:
                                continue
                            
                            # Allocate a single hour in lunch slot (as a last resort)
                            self.solution[(day, time_slot, classroom)] = (section, subject, False)
                            self.section_timetables[section][day][time_slot] = (classroom, subject, False)
                            self.classroom_schedules[classroom][day][time_slot] = (section, subject, False)
                            self.classroom_allocation_count[classroom] += 1
                            self.subject_allocations[(section, subject)].append((day, time_slot, classroom, False))
                            
                            remaining_hours -= 1
                            hours_allocated += 1
                            subject_day_allocations[day] += 1
                            day_allocation_counts[day] += 1  # Update global day allocation count
                            break
        
        # Verify that all subject requirements are met
        incomplete_allocations = []
        for (section, subject), (hours, has_lab) in self.subject_requirements.items():
            allocated_hours = 0
            lab_hours = 0
            theory_hours = 0
            
            # Count lab and theory hours separately
            for day, time_slot, classroom, is_lab in self.subject_allocations[(section, subject)]:
                if is_lab:
                    lab_hours += 1  # Count each lab slot as 1 hour
                else:
                    # Calculate the duration of this slot
                    if "17:00" in time_slot and (day, "16:00-16:55", classroom) in self.solution:
                        continue  # Already counted with the 16:00 slot
                    elif "16:00" in time_slot and (day, "17:00-17:30", classroom) in self.solution:
                        theory_hours += 1.5  # Combined evening slot
                    else:
                        theory_hours += 1  # Regular 1-hour slot
            
            # For subjects with labs, we need 2 hours of lab time and 3 hours of theory time
            # For subjects without labs, we need 3 hours of theory time
            expected_theory_hours = 3
            expected_lab_hours = 2 if has_lab else 0
            total_expected_hours = expected_theory_hours + expected_lab_hours
            
            # Total allocated hours
            allocated_hours = lab_hours + theory_hours
            
            # Check if lab requirements are met
            if has_lab and lab_hours != expected_lab_hours:
                print(f"Warning: {section} - {subject} has {lab_hours} lab hours instead of {expected_lab_hours}")
                
            # Check if theory requirements are met
            if theory_hours < expected_theory_hours:
                print(f"Warning: {section} - {subject} has {theory_hours} theory hours instead of {expected_theory_hours}")
            
            if allocated_hours < total_expected_hours:
                incomplete_allocations.append((section, subject, allocated_hours, total_expected_hours))
                print(f"Incomplete allocation for {section} - {subject}: {allocated_hours}/{total_expected_hours} hours")
        
        # Verify that each section has at least one lunch break per day
        lunch_break_issues = []
        for section in self.sections:
            for day in self.days:
                has_lunch = False
                
                # Check if the preferred lunch slot is free
                if hasattr(self, 'section_lunch_preferences') and section in self.section_lunch_preferences:
                    preferred_slot = self.section_lunch_preferences[section]
                    if preferred_slot not in self.section_timetables[section][day]:
                        has_lunch = True
                else:
                    # Check if any lunch slot is free
                    for slot in self.lunch_slots:
                        if slot not in self.section_timetables[section][day]:
                            has_lunch = True
                            break
                
                if not has_lunch:
                    lunch_break_issues.append((section, day))
                    print(f"No lunch break for {section} on {day}")
                
                self.lunch_breaks[section][day] = has_lunch
        
        # Calculate completion percentage correctly
        total_required_hours = sum(hours for (hours, _) in self.subject_requirements.values())
        total_allocated_hours = 0
        
        # Calculate allocated hours per subject correctly
        for (section, subject), (required_hours, _) in self.subject_requirements.items():
            subject_hours = 0
            for day, time_slot, classroom, is_lab in self.subject_allocations[(section, subject)]:
                if is_lab:
                    # Count lab sessions as 1 hour per slot
                    subject_hours += 1
                else:
                    # Check if this is the combined 16:00-17:30 slot
                    if "16:00-17:30" in time_slot:
                        # Count the combined slot as 1.5 hours
                        subject_hours += 1.5
                    else:
                        # Regular 1-hour slot
                        subject_hours += 1
            
            # Add the minimum of allocated hours and required hours to the total
            total_allocated_hours += min(subject_hours, required_hours)
        
        # Check if there are any required hours before calculating percentage
        if total_required_hours == 0:
            print("Error: No subjects with hour requirements have been added.")
            return False
            
        completion_percentage = (total_allocated_hours / total_required_hours) * 100
        
        print(f"Solution found in {time.time() - start_time:.2f} seconds")
        print(f"Completion: {completion_percentage:.2f}% ({total_allocated_hours}/{total_required_hours} hours)")
        
        # Print allocation distribution by day
        print("\nAllocation distribution by day:")
        for day in prioritized_days:
            print(f"{day}: {day_allocation_counts[day]} slots")
        
        # Return true if we have a reasonable completion percentage
        return completion_percentage >= 90  # Accept solutions with at least 90% completion
                
    def get_section_timetable(self, section):
            """
            Get the timetable for a specific section
            
            Args:
                section: The section name
                
            Returns:
                dict: A dictionary with the format {day: {time_slot: (classroom, subject, is_lab)}}
            """
            if section not in self.sections:
                return None
            
            return self.section_timetables.get(section, {})
        
    def get_classroom_schedule(self, classroom):
            """
            Get the schedule for a specific classroom
            
            Args:
                classroom: The classroom name
                
            Returns:
                dict: A dictionary with the format {day: {time_slot: (section, subject, is_lab)}}
            """
            if classroom not in self.classrooms:
                return None
            
            return self.classroom_schedules.get(classroom, {})