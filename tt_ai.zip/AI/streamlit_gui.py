#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
Streamlit GUI for Classroom Allocation System
Provides a simple, interactive interface for setting up and viewing timetables
"""

import streamlit as st
import pandas as pd
import random
import time

def main():
    st.set_page_config(page_title="Classroom Allocation System", layout="wide")
    
    # Add a heading with custom styling
    st.markdown("""
    <h1 style='text-align: center; color: #1E88E5;'>Classroom Allocation System</h1>
    <p style='text-align: center; font-size: 18px;'>An intelligent system for optimizing classroom schedules</p>
    <hr>
    """, unsafe_allow_html=True)
    
    # Initialize session state for data storage
    if 'sections' not in st.session_state:
        st.session_state.sections = []
    if 'subjects' not in st.session_state:
        st.session_state.subjects = {}  # {section: [subject1, subject2, ...]}
    if 'subject_labs' not in st.session_state:
        st.session_state.subject_labs = {}  # {(section, subject): has_lab}
    if 'classrooms' not in st.session_state:
        st.session_state.classrooms = []
    if 'days' not in st.session_state:
        # Ensure days are in correct order with Saturday at the end
        st.session_state.days = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"]
    if 'time_slots' not in st.session_state:
        st.session_state.time_slots = [
            "9:00-9:55", "10:00-10:55", "11:00-11:55", "12:00-12:55",
            "13:00-13:55", "14:00-14:55", "15:00-15:55", "16:00-17:30"
        ]
    if 'common_subjects' not in st.session_state:
        st.session_state.common_subjects = []
    if 'allocator' not in st.session_state:
        st.session_state.allocator = None
    
    # Create tabs
    tab1, tab2, tab3 = st.tabs(["Setup", "Section Timetables", "Room Schedules"])
    
    with tab1:
        setup_tab()
    
    with tab2:
        timetable_tab()
    
    with tab3:
        room_schedule_tab()

def setup_tab():
    st.header("Setup")
    
    # Quick setup section
    with st.expander("Quick Setup", expanded=True):
        col1, col2, col3 = st.columns(3)
        
        with col1:
            st.subheader("Create Sections")
            section_prefix = st.text_input("Section Prefix", "Section ")
            section_start = st.number_input("From", 1, 100, 1)
            section_end = st.number_input("To", 1, 100, 5)
            
            if st.button("Create Sections"):
                create_section_range(section_prefix, section_start, section_end)
        
        with col2:
            st.subheader("Common Subjects")
            common_subjects = st.text_input("Enter subjects (comma separated)", "Math, Physics, Chemistry")
            
            if st.button("Apply to All"):
                apply_common_subjects(common_subjects)
        
        with col3:
            st.subheader("Create Classrooms")
            classroom_prefix = st.text_input("Room Prefix", "Room ")
            classroom_start = st.number_input("From", 1, 100, 1, key="room_start")
            classroom_end = st.number_input("To", 1, 100, 5, key="room_end")
            
            if st.button("Create Classrooms"):
                create_classroom_range(classroom_prefix, classroom_start, classroom_end)
    
    # Sections and Classrooms
    col1, col2 = st.columns(2)
    
    with col1:
        st.subheader("Sections")
        sections_df = pd.DataFrame({"Sections": st.session_state.sections})
        st.dataframe(sections_df, height=300)
        
        # Improved section management layout
        with st.container():
            st.write("Section Management")
            
            # Add section
            new_section = st.text_input("New Section Name")
            if st.button("Add Section", key="add_section_btn"):
                if new_section:
                    add_section(new_section)
                else:
                    st.warning("Please enter a section name")
            
            # Remove section
            st.write("---")
            section_to_remove = st.selectbox("Select Section to Remove", [""] + st.session_state.sections)
            if st.button("Remove Section", key="remove_section_btn"):
                if section_to_remove:
                    remove_section(section_to_remove)
                else:
                    st.warning("Please select a section to remove")
    
    with col2:
        st.subheader("Classrooms")
        classrooms_df = pd.DataFrame({"Classrooms": st.session_state.classrooms})
        st.dataframe(classrooms_df, height=300)
        
        # Improved classroom management layout
        with st.container():
            st.write("Classroom Management")
            
            # Add classroom
            new_classroom = st.text_input("New Classroom Name")
            if st.button("Add Classroom", key="add_classroom_btn"):
                if new_classroom:
                    add_classroom(new_classroom)
                else:
                    st.warning("Please enter a classroom name")
            
            # Remove classroom
            st.write("---")
            classroom_to_remove = st.selectbox("Select Classroom to Remove", [""] + st.session_state.classrooms)
            if st.button("Remove Classroom", key="remove_classroom_btn"):
                if classroom_to_remove:
                    remove_classroom(classroom_to_remove)
                else:
                    st.warning("Please select a classroom to remove")
    
    # Subjects for selected section
    st.subheader("Subjects")
    selected_section = st.selectbox("Select Section", [""] + st.session_state.sections, key="subject_section_select")
    
    if selected_section:
        subjects = st.session_state.subjects.get(selected_section, [])
        subject_data = []
        
        for subject in subjects:
            has_lab = st.session_state.subject_labs.get((selected_section, subject), False)
            subject_data.append({"Subject": subject, "Has Lab": "Yes" if has_lab else "No"})
        
        subjects_df = pd.DataFrame(subject_data)
        st.dataframe(subjects_df, height=300)
        
        # Improved subject management layout
        st.write("Subject Management")
        
        col3a, col3b = st.columns(2)
        
        with col3a:
            # Add subject
            st.write("Add New Subject")
            new_subject = st.text_input("Subject Name")
            has_lab = st.checkbox("Has Lab Component")
            
            if st.button("Add Subject", key="add_subject_btn"):
                if new_subject:
                    add_subject(selected_section, new_subject, has_lab)
                else:
                    st.warning("Please enter a subject name")
        
        with col3b:
            # Remove subject
            st.write("Remove Subject")
            subject_to_remove = st.selectbox("Select Subject", [""] + subjects, key="remove_subject_select")
            
            if st.button("Remove Subject", key="remove_subject_btn"):
                if subject_to_remove:
                    remove_subject(selected_section, subject_to_remove)
                else:
                    st.warning("Please select a subject to remove")
            
            # Toggle lab
            st.write("---")
            st.write("Toggle Lab Status")
            subject_to_toggle = st.selectbox("Select Subject", [""] + subjects, key="toggle_lab_select")
            
            if st.button("Toggle Lab Status", key="toggle_lab_btn"):
                if subject_to_toggle:
                    toggle_lab(selected_section, subject_to_toggle)
                else:
                    st.warning("Please select a subject")
    
    # Generate timetables button
    if st.button("Generate Timetables", type="primary"):
        with st.spinner("Generating timetables..."):
            generate_timetables()

def timetable_tab():
    st.header("Section Timetables")
    
    # Check if timetables have been generated
    if not st.session_state.allocator:
        st.info("No timetables generated yet. Go to Setup tab and generate timetables first.")
        return
    
    # Select section to display
    selected_section = st.selectbox(
        "Select Section", 
        st.session_state.sections,
        key="timetable_section_select"
    )
    
    if selected_section:
        # Get timetable for the selected section
        timetable = st.session_state.allocator.get_section_timetable(selected_section)
        
        if timetable:
            # Create a DataFrame for the timetable
            timetable_data = []
            
            # Use time slots directly - 16:00-17:30 is already combined
            display_time_slots = st.session_state.time_slots
            
            # Add header row with time slots
            header = ["Day"] + display_time_slots
            
            # Create rows for each day
            for day in st.session_state.days:
                row = [day]
                
                # Skip Saturday (it's kept blank for future use)
                if day == "Saturday":
                    # Add empty cells for all time slots
                    row.extend(["-"] * len(display_time_slots))
                    timetable_data.append(row)
                    continue
                
                for time_slot in display_time_slots:
                    # Handle regular slots
                    if time_slot in timetable[day]:
                        classroom, subject, is_lab = timetable[day][time_slot]
                        # Only add lab indicator if it's actually a lab session
                        lab_text = " L" if is_lab else ""
                        cell_text = f"{subject}{lab_text} ({classroom})"
                        row.append(cell_text)
                    else:
                        row.append("-")
                
                timetable_data.append(row)
            
            # Create DataFrame
            df = pd.DataFrame(timetable_data, columns=header)
            
            # Display the timetable
            st.dataframe(df, use_container_width=True, height=400)
            
            # Add download button for CSV
            csv = df.to_csv(index=False)
            st.download_button(
                label="Download Timetable as CSV",
                data=csv,
                file_name=f"{selected_section}_timetable.csv",
                mime="text/csv"
            )
        else:
            st.warning(f"No timetable data available for {selected_section}")

def room_schedule_tab():
    st.header("Room Schedules")
    
    # Check if timetables have been generated
    if not st.session_state.allocator:
        st.info("No room schedules generated yet. Go to Setup tab and generate timetables first.")
        return
    
    # Select classroom to display
    selected_classroom = st.selectbox(
        "Select Classroom", 
        st.session_state.classrooms,
        key="room_schedule_select"
    )
    
    if selected_classroom:
        # Get schedule for the selected classroom
        schedule = st.session_state.allocator.get_classroom_schedule(selected_classroom)
        
        if schedule:
            # Create a DataFrame for the schedule
            schedule_data = []
            
            # Use time slots directly - 16:00-17:30 is already combined
            display_time_slots = st.session_state.time_slots
            
            # Add header row with time slots
            header = ["Day"] + display_time_slots
            
            # Create rows for each day
            for day in st.session_state.days:
                row = [day]
                
                # Skip Saturday (it's kept blank for future use)
                if day == "Saturday":
                    # Add empty cells for all time slots
                    row.extend(["-"] * len(display_time_slots))
                    schedule_data.append(row)
                    continue
                
                for time_slot in display_time_slots:
                    # Handle regular slots
                    if time_slot in schedule[day]:
                        section, subject, is_lab = schedule[day][time_slot]
                        # Only add lab indicator if it's actually a lab session
                        lab_text = " L" if is_lab else ""
                        cell_text = f"{section}\n{subject}{lab_text}"
                        row.append(cell_text)
                    else:
                        row.append("-")
                
                schedule_data.append(row)
            
            # Create DataFrame
            df = pd.DataFrame(schedule_data, columns=header)
            
            # Display the schedule
            st.dataframe(df, use_container_width=True, height=400)
            
            # Add download button for CSV
            csv = df.to_csv(index=False)
            st.download_button(
                label="Download Schedule as CSV",
                data=csv,
                file_name=f"{selected_classroom}_schedule.csv",
                mime="text/csv"
            )
        else:
            st.warning(f"No schedule data available for {selected_classroom}")

def create_section_range(prefix, start, end):
    """Create a range of sections with the given prefix"""
    try:
        for i in range(int(start), int(end) + 1):
            section_name = f"{prefix}{i}"
            if section_name not in st.session_state.sections:
                st.session_state.sections.append(section_name)
                st.session_state.subjects[section_name] = []
                
                # Apply common subjects if any
                if st.session_state.common_subjects:
                    for subject in st.session_state.common_subjects:
                        st.session_state.subjects[section_name].append(subject)
        
        st.success(f"Created sections from {prefix}{start} to {prefix}{end}")
    except ValueError:
        st.error("Please enter valid numbers for start and end")

def apply_common_subjects(subjects_str):
    """Apply common subjects to all sections"""
    if not subjects_str.strip():
        st.warning("Please enter at least one subject")
        return
    
    # Parse the comma-separated subjects
    subjects = [s.strip() for s in subjects_str.split(",") if s.strip()]
    
    if not subjects:
        st.warning("Please enter valid subjects")
        return
    
    # Store as common subjects
    st.session_state.common_subjects = subjects
    
    # Apply to all existing sections
    for section in st.session_state.sections:
        # Clear existing subjects
        st.session_state.subjects[section] = []
        
        # Add common subjects
        for subject in subjects:
            st.session_state.subjects[section].append(subject)
            # Default lab status to False
            st.session_state.subject_labs[(section, subject)] = False
    
    st.success(f"Applied {len(subjects)} common subjects to all sections")

def create_classroom_range(prefix, start, end):
    """Create a range of classrooms with the given prefix"""
    try:
        for i in range(int(start), int(end) + 1):
            classroom_name = f"{prefix}{i}"
            if classroom_name not in st.session_state.classrooms:
                st.session_state.classrooms.append(classroom_name)
        
        st.success(f"Created classrooms from {prefix}{start} to {prefix}{end}")
    except ValueError:
        st.error("Please enter valid numbers for start and end")

def add_section(section_name):
    """Add a new section"""
    if section_name in st.session_state.sections:
        st.warning(f"Section {section_name} already exists")
        return
    
    st.session_state.sections.append(section_name)
    st.session_state.subjects[section_name] = []
    
    # Apply common subjects if any
    if st.session_state.common_subjects:
        for subject in st.session_state.common_subjects:
            st.session_state.subjects[section_name].append(subject)
            st.session_state.subject_labs[(section_name, subject)] = False
    
    st.success(f"Added section: {section_name}")

def remove_section(section_name):
    """Remove a section"""
    if section_name in st.session_state.sections:
        st.session_state.sections.remove(section_name)
        if section_name in st.session_state.subjects:
            del st.session_state.subjects[section_name]
        
        # Remove any lab entries for this section
        keys_to_remove = []
        for key in st.session_state.subject_labs:
            if key[0] == section_name:
                keys_to_remove.append(key)
        
        for key in keys_to_remove:
            del st.session_state.subject_labs[key]
        
        st.success(f"Removed section: {section_name}")

def add_classroom(classroom_name):
    """Add a new classroom"""
    if classroom_name in st.session_state.classrooms:
        st.warning(f"Classroom {classroom_name} already exists")
        return
    
    st.session_state.classrooms.append(classroom_name)
    st.success(f"Added classroom: {classroom_name}")

def remove_classroom(classroom_name):
    """Remove a classroom"""
    if classroom_name in st.session_state.classrooms:
        st.session_state.classrooms.remove(classroom_name)
        st.success(f"Removed classroom: {classroom_name}")

def add_subject(section, subject, has_lab):
    """Add a subject to a section"""
    if subject in st.session_state.subjects[section]:
        st.warning(f"Subject {subject} already exists for {section}")
        return
    
    st.session_state.subjects[section].append(subject)
    st.session_state.subject_labs[(section, subject)] = has_lab
    st.success(f"Added subject {subject} to {section}")

def remove_subject(section, subject):
    """Remove a subject from a section"""
    if subject in st.session_state.subjects[section]:
        st.session_state.subjects[section].remove(subject)
        if (section, subject) in st.session_state.subject_labs:
            del st.session_state.subject_labs[(section, subject)]
        st.success(f"Removed subject {subject} from {section}")

def toggle_lab(section, subject):
    """Toggle lab status for a subject"""
    if subject in st.session_state.subjects[section]:
        current_status = st.session_state.subject_labs.get((section, subject), False)
        st.session_state.subject_labs[(section, subject)] = not current_status
        new_status = "enabled" if not current_status else "disabled"
        st.success(f"Lab component {new_status} for {subject} in {section}")

def generate_timetables():
    try:
        from classroom_allocation import ClassroomAllocation
        
        # Create a CSP solver
        allocator = ClassroomAllocation(
            st.session_state.classrooms, 
            st.session_state.sections, 
            # Exclude Saturday from allocation days
            [day for day in st.session_state.days if day != "Saturday"], 
            st.session_state.time_slots
        )
        
        # Define lunch slots
        lunch_slots = ["12:00-12:55", "13:00-13:55"]
        allocator.lunch_slots = lunch_slots
        
        # Add method to check if a time slot is lunch time
        def is_lunch_time(time_slot):
            return time_slot in lunch_slots
        
        allocator.is_lunch_time = is_lunch_time
        
        # Check if there are any subjects to allocate
        if not any(st.session_state.subjects.values()):
            st.error("No subjects have been added. Please add at least one subject for each section.")
            return
        
        # Add subjects with their requirements
        for section in st.session_state.sections:
            if section not in st.session_state.subjects or not st.session_state.subjects[section]:
                st.warning(f"No subjects added for {section}. Please add at least one subject.")
                continue
                
            for subject in st.session_state.subjects.get(section, []):
                # Each subject has exactly 3 hours per week (fixed)
                has_lab = st.session_state.subject_labs.get((section, subject), False)
                allocator.add_subject(section, subject, has_lab)
        
        # Configure lunch break strategy - alternate lunch hours between sections
        # Even-indexed sections get 12:00-12:55 lunch break
        # Odd-indexed sections get 13:00-13:55 lunch break
        allocator.section_lunch_preferences = {}
        for i, section in enumerate(st.session_state.sections):
            if i % 2 == 0:
                allocator.section_lunch_preferences[section] = "12:00-12:55"
            else:
                allocator.section_lunch_preferences[section] = "13:00-13:55"
        
        # Set a time limit - 180 seconds should be sufficient
        time_limit = 180
        
        # Try to solve
        with st.spinner(f"Generating timetables (this may take up to {time_limit} seconds)..."):
            result = allocator.solve(time_limit=time_limit)
            
            # Add Saturday back to the allocator's days list (but with no allocations)
            allocator.days = st.session_state.days
            # Initialize empty dictionaries for Saturday
            for section in allocator.sections:
                allocator.section_timetables[section]["Saturday"] = {}
            for classroom in allocator.classrooms:
                allocator.classroom_schedules[classroom]["Saturday"] = {}
            
            st.session_state.allocator = allocator  # Store the allocator
            
            if result:
                st.success("Timetables generated successfully!")
            else:
                st.warning(
                    "Could not find a complete solution.\n"
                    "Some subjects may not have all required hours allocated.\n"
                    "You can still view the partial timetables."
                )
                
            # Display a note about Saturday being a reserve day
            st.info("Note: Saturday is included as a reserve day and is intentionally kept empty.")
            
    except Exception as e:
        st.error(f"An error occurred: {str(e)}")
        import traceback
        st.error(f"Traceback: {traceback.format_exc()}")
        st.session_state.allocator = None

def display_section_timetable(section):
    """Display the timetable for a specific section"""
    if not st.session_state.allocator:
        st.warning("Please generate timetables first.")
        return
    
    timetable = st.session_state.allocator.get_section_timetable(section)
    if not timetable:
        st.warning(f"No timetable found for {section}.")
        return
    
    # Create a DataFrame for the timetable
    df = pd.DataFrame(index=range(len(st.session_state.days)), 
                     columns=["Day"] + st.session_state.time_slots)
    
    # Fill the DataFrame
    for i, day in enumerate(st.session_state.days):
        df.iloc[i, 0] = day
        for j, time_slot in enumerate(st.session_state.time_slots):
            if time_slot in timetable[day]:
                classroom, subject, is_lab = timetable[day][time_slot]
                # Updated format: Subject L (Room) for labs
                if is_lab:
                    df.iloc[i, j+1] = f"{subject} L @ {classroom}"
                else:
                    df.iloc[i, j+1] = f"{subject} @ {classroom}"
            else:
                df.iloc[i, j+1] = "-"
    
    # Display the timetable
    st.dataframe(df, use_container_width=True)

if __name__ == "__main__":
    main()