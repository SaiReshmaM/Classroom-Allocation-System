#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
Main entry point for the Classroom Allocation System
"""

import os

def main():
    """Main function to start the application"""
    print("\n=== CLASSROOM ALLOCATION SYSTEM ===\n")
    print("Starting Streamlit Interface...")
    
    try:
        os.system("streamlit run streamlit_gui.py")
    except Exception as e:
        print(f"Error starting Streamlit: {e}")
        print("Make sure Streamlit is installed with: pip install streamlit pandas")

if __name__ == "__main__":
    main()